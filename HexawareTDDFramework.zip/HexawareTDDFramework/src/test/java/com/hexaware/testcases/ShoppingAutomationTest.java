package com.hexaware.testcases;

public class ShoppingAutomationTest {

}
