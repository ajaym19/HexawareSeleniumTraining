package com.hexaware.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hexaware.base.Base;
import com.hexaware.pages.HomePage;
import com.hexaware.pages.LoginPage;

public class HomePageTest extends Base {

	LoginPage lp;
	HomePage hp;

	@BeforeMethod
	public void browserSetup() {
		initialization();
		lp = new LoginPage();
		hp = lp.login(properties.getProperty("username"), properties.getProperty("password"));

	}

	@Test
	public void validateHomePageTitleTest() {
		Assert.assertEquals(hp.getHomePageTitle(), "Automation");
	}

	@Test
	public void validateMenuSize() {
		//there should be 5 menu's
		Assert.assertEquals(hp.getMenuCount(), 5);
	}
	
	@Test
	public void validateMenuLabel() {
		//validate that the menu are displayed as expected
		
	}

	@AfterMethod
	public void closeSetup() {
		tearDown();
	}
}
