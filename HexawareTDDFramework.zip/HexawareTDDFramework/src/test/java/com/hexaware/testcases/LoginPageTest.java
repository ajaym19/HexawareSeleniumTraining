package com.hexaware.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.hexaware.base.Base;
import com.hexaware.pages.HomePage;
import com.hexaware.pages.LoginPage;

public class LoginPageTest extends Base {

	LoginPage lp;
	HomePage hp;

	@BeforeSuite
	public void reportConfig() {
		reportSetup();
	}
	
	@BeforeMethod
	public void browserSetup() {
		initialization();
		lp = new LoginPage();

	}

	@Test(priority = 2)
	public void validateTitleTest() {
		ExtentTest test = extent.createTest("Valdiating the Title of the Login Page");
		logger.info("Started Execution of validateTitleTest TC !!!");
		Assert.assertEquals(lp.getTitle(), "Learn Automation");
		logger.info("Execution Completed of validateTitleTest TC !!!");
		test.log(Status.PASS, "Login Page Title Validatio TC passed!!!");
	}

	@Test(enabled = true, priority = 1)
	public void validateLoginTest() {
		hp = lp.login(properties.getProperty("username"), properties.getProperty("password"));
		// verify if the user has successfully logged in
		Assert.assertEquals(hp.getHomePageTitle(), "Automation");
	}

	@Test
	public void validatePasswordMismatchSignUp() {
		boolean messagePresent = lp.signUpPasswordMismatch("AJay", "admin@1", "admin@2", "test@gmail.com");
		Assert.assertTrue(messagePresent);
		ExtentTest test = extent.createTest("Validating incorrect password");
		test.log(Status.FAIL, "Failed TC!!!");
	}

	@AfterMethod
	public void closeSetup() {
		tearDown();
	}
	
	@AfterSuite
	public void generateReport() {
		reportTearDown();
	}
	
}
