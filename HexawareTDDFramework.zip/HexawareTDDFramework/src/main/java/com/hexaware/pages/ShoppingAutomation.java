package com.hexaware.pages;

public class ShoppingAutomation {

}
