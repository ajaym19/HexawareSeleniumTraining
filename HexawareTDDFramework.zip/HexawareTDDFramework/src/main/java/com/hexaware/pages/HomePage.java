package com.hexaware.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.hexaware.base.Base;

public class HomePage extends Base {

	// code
	public String getHomePageTitle() {
		return driver.getTitle();
	}

	public int getMenuCount() {
		List<WebElement> menus = driver.findElements(By.xpath("//li/a"));
		return menus.size();
	}
}
