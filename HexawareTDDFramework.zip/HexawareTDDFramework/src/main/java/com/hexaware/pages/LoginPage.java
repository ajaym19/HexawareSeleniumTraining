package com.hexaware.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.hexaware.base.Base;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPage extends Base {

	public HomePage login(String username, String password) {
		driver.findElement(By.id("user")).sendKeys(username);
		driver.findElement(By.id("pass")).sendKeys(password);
		driver.findElement(By.id("submit")).click();
		captureScreenshot();
		return new HomePage();
	}

	public String getTitle() {
		return driver.getTitle();
	}

	public boolean signUpPasswordMismatch(String uname, String pwd, String rpwd, String email) {
		driver.findElement(By.id("forgotPass")).click();
		driver.findElement(By.id("user2")).sendKeys(uname);
		driver.findElement(By.id("pass2")).sendKeys(pwd);
		driver.findElement(By.id("repeatPass")).sendKeys(rpwd);
		driver.findElement(By.id("email")).sendKeys(email);
		driver.findElement(By.id("submitReg")).click();
		boolean errorMessagePresent = driver
				.findElement(By.xpath("//h4[text()='Password and repeat password must be the same']")).isDisplayed();
		return errorMessagePresent;
	}

}
