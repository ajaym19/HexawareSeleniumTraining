package com.hexaware.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public abstract class Base {

	public static WebDriver driver;
	public static Properties properties;
	public static Logger logger;
	public static ExtentReports extent;
	public static ExtentSparkReporter reporter;
	private static String reportPath;

	public Base() {
		properties = new Properties();
		String configPath = "./src/main/java/com/hexaware/config/config.properties";
		try {
			FileInputStream fis = new FileInputStream(configPath);
			properties.load(fis);
		} catch (FileNotFoundException e) {
			System.out.println("Cannot find the properties file!!!");
		} catch (IOException e) {
			System.out.println("Cannot read the properties file!!!");
		}
	}

	public static void initialization() {
		logger = Logger.getLogger(Base.class);
		String browser = properties.getProperty("browser");

		if (browser.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			logger.info("Identified and launched Chrome Browser!!!");
		} else if (browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			logger.info("Identified and launched Firefox Browser!!!");
		} else if (browser.equalsIgnoreCase("ie")) {
			WebDriverManager.iedriver().setup();
			driver = new InternetExplorerDriver();
		} else if (browser.equalsIgnoreCase("safari")) {
			WebDriverManager.safaridriver().setup();
			driver = new SafariDriver();
		}

		driver.get(properties.getProperty("url"));
		logger.info("Application is launched!!!");
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	public static void tearDown() {
		driver.quit();
		logger.info("Browser setup is closed!!!");
	}

	public static void captureScreenshot() {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		String formattedDate = formatter.format(new Date());
		formattedDate = formattedDate.replaceAll("/", "_").replaceAll(":", "_") + ".png";
		TakesScreenshot scr = (TakesScreenshot) driver;
		File srcFile = scr.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(srcFile, new File("./Screenshots/test" + formattedDate));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void reportSetup() {
		reportPath = System.getProperty("user.dir")+"/ExtentReports/report.html";
		reporter = new ExtentSparkReporter(reportPath);
		//ExtentSparkReporter can be used to do below config
		reporter.config().setDocumentTitle("Hexaware Test Reports");
		reporter.config().setReportName("Automation Result");
		
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Tester", "Ajay Mishra");
		extent.setSystemInfo("Sprint", "Sprint 3.0");
		extent.setSystemInfo("Environment", "QA");
		extent.setSystemInfo("Browser", properties.getProperty("browser"));
	}
	
	public void reportTearDown() {
		extent.flush();
	}
}
